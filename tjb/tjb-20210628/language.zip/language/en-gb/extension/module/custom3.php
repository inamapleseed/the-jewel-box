<?php

$_['heading_title'] = 'Custom 3';